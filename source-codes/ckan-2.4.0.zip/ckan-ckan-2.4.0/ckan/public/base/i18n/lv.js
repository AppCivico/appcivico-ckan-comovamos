{
  "": {
    "domain": "ckan",
    "lang": "lv",
    "plural-forms": "nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);"
  }
}
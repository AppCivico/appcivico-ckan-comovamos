{
  "": {
    "domain": "ckan",
    "lang": "hu",
    "plural-forms": "nplurals=2; plural=(n != 1);"
  },
  "Cancel": [
    null,
    "Mégse"
  ],
  "Edit": [
    null,
    "Módosítás"
  ],
  "Loading...": [
    null,
    "Betöltés ..."
  ],
  "URL": [
    null,
    "URL"
  ],
  "Upload a file": [
    null,
    "Fájl feltöltése"
  ]
}
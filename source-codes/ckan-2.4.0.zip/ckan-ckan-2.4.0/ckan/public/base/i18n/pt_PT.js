{
  "": {
    "domain": "ckan",
    "lang": "pt_PT",
    "plural-forms": "nplurals=2; plural=(n != 1);"
  },
  "An Error Occurred": [
    null,
    "Ocorreu Um Erro"
  ],
  "Are you sure you want to perform this action?": [
    null,
    "Tem a certeza que deseja realizar este ação?"
  ],
  "Cancel": [
    null,
    "Cancelar"
  ],
  "Confirm": [
    null,
    "Confirmar"
  ],
  "Edit": [
    null,
    "Editar"
  ],
  "Follow": [
    null,
    "Seguir"
  ],
  "Hide": [
    null,
    "Ocultar"
  ],
  "Image": [
    null,
    "Imagem"
  ],
  "Link": [
    null,
    "Hiperligação"
  ],
  "Loading...": [
    null,
    "A carregar ..."
  ],
  "No matches found": [
    null,
    "Não foram encontradas correspondências"
  ],
  "Please Confirm Action": [
    null,
    "Por favor, Confirme a Ação"
  ],
  "Remove": [
    null,
    "Remover"
  ],
  "Reorder resources": [
    null,
    "Reordenar recursos"
  ],
  "Resource uploaded": [
    null,
    "Recurso enviado"
  ],
  "Save order": [
    null,
    "Guardar ordenação"
  ],
  "Saving...": [
    null,
    "A guardar ..."
  ],
  "Show more": [
    null,
    "Mostrar mais"
  ],
  "URL": [
    null,
    "URL"
  ],
  "Unfollow": [
    null,
    "Não Seguir"
  ],
  "Upload": [
    null,
    "Enviar"
  ],
  "Upload a file": [
    null,
    "Enviar um ficheiro"
  ],
  "Upload a file on your computer": [
    null,
    "Envie um ficheiro no seu computador"
  ],
  "show less": [
    null,
    "mostrar menos"
  ],
  "show more": [
    null,
    "mostrar mais"
  ]
}
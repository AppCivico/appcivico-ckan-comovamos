DEBUG = True
TESTING = True

SQLALCHEMY_DATABASE_URI = 'sqlite://'

NAME = 'datapusher'

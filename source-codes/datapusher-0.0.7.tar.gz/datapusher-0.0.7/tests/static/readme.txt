october_2011.csv
================

From: http://thedatahub.org/dataset/newcastle-city-council-payments-over-500/resource/1d1c9089-7037-48a3-a70d-fbecf146238f

bus-stops.csv
=============

From: http://data.gov.uk/dataset/sunderland-bus-stops
License: OGL (https://www.nationalarchives.gov.uk/doc/open-government-licence/)
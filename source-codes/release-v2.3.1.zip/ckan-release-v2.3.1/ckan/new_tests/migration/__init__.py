'''**All migration scripts should have tests.**

.. todo::

   Write some tests for a migration script, and then use them as an example to
   fill out this guidelines section.

'''

'''**All model methods should have tests**.

.. todo::

   Write the tests for one ``ckan.model`` module, figuring out the best way
   to write model tests. Then fill in this guidelines section, using the first
   set of model tests as an example.

'''

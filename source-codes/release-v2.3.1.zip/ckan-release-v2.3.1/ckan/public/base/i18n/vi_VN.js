{
  "": {
    "domain": "ckan",
    "lang": "vi_VN",
    "plural-forms": "nplurals=1; plural=0;"
  }
}
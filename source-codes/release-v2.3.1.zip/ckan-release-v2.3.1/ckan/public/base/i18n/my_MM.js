{
  "": {
    "domain": "ckan",
    "lang": "my_MM",
    "plural-forms": "nplurals=1; plural=0;"
  }
}
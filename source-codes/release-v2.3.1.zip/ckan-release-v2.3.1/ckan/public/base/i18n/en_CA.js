{
  "": {
    "domain": "ckan",
    "lang": "en_CA",
    "plural-forms": "nplurals=2; plural=(n != 1);"
  }
}
{
  "": {
    "domain": "ckan",
    "lang": "fa_IR",
    "plural-forms": "nplurals=1; plural=0;"
  }
}
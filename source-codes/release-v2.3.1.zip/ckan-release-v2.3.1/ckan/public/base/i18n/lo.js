{
  "": {
    "domain": "ckan",
    "lang": "lo",
    "plural-forms": "nplurals=1; plural=0;"
  }
}
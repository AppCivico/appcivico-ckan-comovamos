{
  "": {
    "domain": "ckan",
    "lang": "my",
    "plural-forms": "nplurals=1; plural=0;"
  }
}
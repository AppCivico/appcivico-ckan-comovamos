{
  "": {
    "domain": "ckan",
    "lang": "sw",
    "plural-forms": "nplurals=2; plural=(n != 1);"
  }
}
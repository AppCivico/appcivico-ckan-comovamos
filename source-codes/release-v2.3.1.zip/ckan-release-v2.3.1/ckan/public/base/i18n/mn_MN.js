{
  "": {
    "domain": "ckan",
    "lang": "mn_MN",
    "plural-forms": "nplurals=2; plural=(n != 1);"
  },
  "An Error Occurred": [
    null,
    "Алдаа гарлаа"
  ],
  "Are you sure you want to perform this action?": [
    null,
    "Та тус үйлдлийг гүйцэтгэхдээ итгэлтэй байна уу?"
  ],
  "Cancel": [
    null,
    "Цуцлах"
  ],
  "Confirm": [
    null,
    "Зөвшөөрөх"
  ],
  "Edit": [
    null,
    "Засварлах"
  ],
  "Failed to load data API information": [
    null,
    "Өгөгдлийн API мэдээллийг ачааллахад алдаа гарлаа"
  ],
  "Follow": [
    null,
    "Дагах"
  ],
  "Hide": [
    null,
    "Нуух"
  ],
  "Image": [
    null,
    "Зураг"
  ],
  "Input is too short, must be at least one character": [
    null,
    "Хэт богино! Хамгийн багадаа 1 тэмдэгт оруулах ёстой"
  ],
  "Link": [
    null,
    "Холбоос"
  ],
  "Link to a URL on the internet (you can also link to an API)": [
    null,
    "Интернетэд байрлах замтай холбох (мөн API-тай холбож болно)"
  ],
  "Loading...": [
    null,
    "Ачааллаж байна..."
  ],
  "No matches found": [
    null,
    "Тохирох зүйл олдсонгүй"
  ],
  "Please Confirm Action": [
    null,
    "Үйлдлээ баталгаажуулна уу"
  ],
  "Remove": [
    null,
    "Устгах"
  ],
  "Reorder resources": [
    null,
    "Материалыг дахин эрэмбэлэх"
  ],
  "Resource uploaded": [
    null,
    "Материал хуулагдлаа"
  ],
  "Save order": [
    null,
    "Дарааллыг хадгалах"
  ],
  "Saving...": [
    null,
    "Хадгалж байна.."
  ],
  "Show more": [
    null,
    "Дэлгэрэнгүй"
  ],
  "Start typing…": [
    null,
    "Бичиж эхлэнэ үү..."
  ],
  "There are unsaved modifications to this form": [
    null,
    "Энэ маягтанд хадгалагдаагүй өөрчлөлтүүд байна."
  ],
  "There is no API data to load for this resource": [
    null,
    "Тус материалыг ачааллах API өгөгдөл байхгүй байна"
  ],
  "URL": [
    null,
    "URL"
  ],
  "Unable to authenticate upload": [
    null,
    "Хуулах эрхийг баталгаажуулах боломжгүй байна"
  ],
  "Unable to get data for uploaded file": [
    null,
    "Хуулсан файлын мэдээллийг авах боломжгүй"
  ],
  "Unable to upload file": [
    null,
    "Файлыг хуулах боломжгүй байна"
  ],
  "Unfollow": [
    null,
    "Дагахаа болих"
  ],
  "Upload": [
    null,
    "Хуулах"
  ],
  "Upload a file": [
    null,
    "Файл хуулах"
  ],
  "Upload a file on your computer": [
    null,
    "Компьютерээс файл хуулах"
  ],
  "You are uploading a file. Are you sure you want to navigate away and stop this upload?": [
    null,
    "Та яг одоо файл хуулж байна. Хуулж байгаа файлаа зогсоогоод гарахдаа итгэлтэй байна уу."
  ],
  "show less": [
    null,
    "хураангуй"
  ],
  "show more": [
    null,
    "дэлгэрэнгүй"
  ]
}
{
  "": {
    "domain": "ckan",
    "lang": "es_MX",
    "plural-forms": "nplurals=2; plural=(n != 1);"
  }
}
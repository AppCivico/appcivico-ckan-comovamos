{
  "": {
    "domain": "ckan",
    "lang": "eu",
    "plural-forms": "nplurals=2; plural=(n != 1);"
  }
}
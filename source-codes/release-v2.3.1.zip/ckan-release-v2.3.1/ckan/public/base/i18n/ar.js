{
  "": {
    "domain": "ckan",
    "lang": "ar",
    "plural-forms": "nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;"
  },
  "Cancel": [
    null,
    "إلغاء"
  ],
  "Edit": [
    null,
    "تحرير"
  ],
  "Follow": [
    null,
    "تابع"
  ],
  "Hide": [
    null,
    "إخفاء"
  ],
  "Show more": [
    null,
    "إظهار المزيد"
  ],
  "Upload a file": [
    null,
    "تحميل ملف"
  ]
}